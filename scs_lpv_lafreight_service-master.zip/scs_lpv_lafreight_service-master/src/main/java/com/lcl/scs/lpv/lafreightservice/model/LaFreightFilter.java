package com.lcl.scs.lpv.lafreightservice.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "LAInboundFreightInformationFilter")
public class LaFreightFilter {
	@Id
	private String id;
	private String shipmentNo;
	private String orderType;
	private String laFileName;
	private String laDeliveryFileName;
	private String processType;
	private String shipmentType;
	private String shipMode;
	private String countryOfOrigin;
	private String plannedShipDate;
	private String fromLoc;
	private String toLoc;
	private String from;
	private String to;
	private String shipFromOwner;
	private String shipToOwner;
	private String quantity;
	private String trailerNo;
	private String etd;
	private String eta;
	private Date ceationDate;
	private String creationDate;
	private String containerEta;
	private String legCarrier;
	private String legTrailerNo;
	private String legETA;
	private String legTrackingReference;
	private String legShipMode;
	private String operationName;
	private String processIndicator;
	private String mainLeg;
	private String noOfDeliveries;
	private String lineMode;
	private String uDFTotalWeight;
	private String uDFTotalVolume;
	private String packedQty;
	private String equipmentType;
	private String serviceID;
	private String carrierID;
	private String uDFVolume;
	private String uDFWeight;
	private String vendorName;
	private String fullReplace;
	private String fullReplaceLine;
	private String shipState;
	private Date loadingDate;
	private Date processedTimeToLct;
	private String messageId;
	private String containerATA;
	private String reasonDate;
	private String reason;
	private String reasonNotes;
	private List<LpvLaDetailInterface> laDetails;
	
	
	public String getReasonDate() {
		return reasonDate;
	}
	public void setReasonDate(String date) {
		this.reasonDate = date;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getReasonNotes() {
		return reasonNotes;
	}
	public void setReasonNotes(String reasonNotes) {
		this.reasonNotes = reasonNotes;
	}
	public List<LpvLaDetailInterface> getLaDetails() {
		return laDetails;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}
	public String getOrderType() {
		return orderType;
	}
//	public String laIdocFromDB() {
//		return laFileName;
//	}
	public String getProcessIndicator() {
		return processIndicator;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getShipmentType() {
		return shipmentType;
	}
	public void setShipmentType(String shipmentType) {
		this.shipmentType = shipmentType;
	}
	public String getShipMode() {
		return shipMode;
	}
	public void setShipMode(String shipMode) {
		this.shipMode = shipMode;
	}
	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}
	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}
	public String getPlannedShipDate() {
		return plannedShipDate;
	}
	public void setPlannedShipDate(String plannedShipDate) {
		this.plannedShipDate = plannedShipDate;
	}
	public String getFromLoc() {
		return fromLoc;
	}
	public void setFromLoc(String fromLoc) {
		this.fromLoc = fromLoc;
	}
	public String getToLoc() {
		return toLoc;
	}
	public void setToLoc(String toLoc) {
		this.toLoc = toLoc;
	}

	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getShipFromOwner() {
		return shipFromOwner;
	}
	public void setShipFromOwner(String shipFromOwner) {
		this.shipFromOwner = shipFromOwner;
	}
	public String getShipToOwner() {
		return shipToOwner;
	}
	public void setShipToOwner(String shipToOwner) {
		this.shipToOwner = shipToOwner;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	public String getTrailerNo() {
		return trailerNo;
	}
	public void setTrailerNo(String trailerNo) {
		this.trailerNo = trailerNo;
	}
	public String getEtd() {
		return etd;
	}
	public void setEtd(String etd) {
		this.etd = etd;
	}
	public Date getCeationDate() {
		return ceationDate;
	}
	public void setCeationDate(Date ceationDate) {
		this.ceationDate = ceationDate;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String date) {
		this.creationDate = date;
	}
	public String getContainerEta() {
		return containerEta;
	}
	public void setContainerEta(String containerEta) {
		this.containerEta = containerEta;
	}

	public String getLegCarrier() {
		return legCarrier;
	}
	public void setLegCarrier(String legCarrier) {
		this.legCarrier = legCarrier;
	}
	public String getLegTrailerNo() {
		return legTrailerNo;
	}
	public void setLegTrailerNo(String legTrailerNo) {
		this.legTrailerNo = legTrailerNo;
	}
	public String getLegETA() {
		return legETA;
	}
	public void setLegETA(String legETA) {
		this.legETA = legETA;
	}
	public String getLegTrackingReference() {
		return legTrackingReference;
	}
	public void setLegTrackingReference(String legTrackingReference) {
		this.legTrackingReference = legTrackingReference;
	}
	public String getLegShipMode() {
		return legShipMode;
	}
	public void setLegShipMode(String legShipMode) {
		this.legShipMode = legShipMode;
	}
	public String getOperationName() {
		return operationName;
	}
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}
	public String getMainLeg() {
		return mainLeg;
	}
	public void setMainLeg(String mainLeg) {
		this.mainLeg = mainLeg;
	}
	public String getNoOfDeliveries() {
		return noOfDeliveries;
	}
	public void setNoOfDeliveries(String noOfDeliveries) {
		this.noOfDeliveries = noOfDeliveries;
	}

	public String getLineMode() {
		return lineMode;
	}
	public void setLineMode(String lineMode) {
		this.lineMode = lineMode;
	}
	public String getuDFTotalWeight() {
		return uDFTotalWeight;
	}
	public void setuDFTotalWeight(String uDFTotalWeight) {
		this.uDFTotalWeight = uDFTotalWeight;
	}
	public String getuDFTotalVolume() {
		return uDFTotalVolume;
	}
	public void setuDFTotalVolume(String uDFTotalVolume) {
		this.uDFTotalVolume = uDFTotalVolume;
	}
	public String getPackedQty() {
		return packedQty;
	}
	public void setPackedQty(String packedQty) {
		this.packedQty = packedQty;
	}
	public String getEquipmentType() {
		return equipmentType;
	}
	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;
	}
	public String getServiceID() {
		return serviceID;
	}
	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}
	public String getCarrierID() {
		return carrierID;
	}
	public void setCarrierID(String carrierID) {
		this.carrierID = carrierID;
	}
	public String getuDFVolume() {
		return uDFVolume;
	}
	public void setuDFVolume(String uDFVolume) {
		this.uDFVolume = uDFVolume;
	}
	public String getuDFWeight() {
		return uDFWeight;
	}
	public void setuDFWeight(String uDFWeight) {
		this.uDFWeight = uDFWeight;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getFullReplace() {
		return fullReplace;
	}
	public void setFullReplace(String fullReplace) {
		this.fullReplace = fullReplace;
	}
	public String getFullReplaceLine() {
		return fullReplaceLine;
	}
	public void setFullReplaceLine(String fullReplaceLine) {
		this.fullReplaceLine = fullReplaceLine;
	}
	public String getShipState() {
		return shipState;
	}
	public void setShipState(String shipState) {
		this.shipState = shipState;
	}
	
	public void setLoadingDate(Date processDate) {
		this.loadingDate=processDate;
		
	}
	public void setProcessIndicator(String processIndicator) {
		this.processIndicator=processIndicator;
		
	}
	public void setLaFileName(String laFileName) {
		this.laFileName=laFileName;
		
	}
	public void setProcessedTime(Date processedTimeToLct) {
		this.processedTimeToLct=processedTimeToLct;
		
	}
	public void setMessageId(String messageId) {
		this.messageId=messageId;
		
	}
	public void setLaDetails(List<LpvLaDetailInterface> laDetails) {
		this.laDetails=laDetails;
		
	}
	public String getLaDeliveryFileName() {
		return laDeliveryFileName;
	}
	public void setLaDeliveryFileName(String laDeliveryFileName) {
		this.laDeliveryFileName=laDeliveryFileName;;
	}
	public String getContainerATA() {
		return containerATA;
	}
	public void setContainerATA(String containerATA) {
		this.containerATA = containerATA;
	}
	public String getEta() {
		return eta;
	}
	public void setEta(String eta) {
		this.eta = eta;
	}
	public String getLaFileName() {
		return laFileName;
	}

	
	
}
