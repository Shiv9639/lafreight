package com.lcl.scs.lpv.lafreightservice.service;

import java.util.List;

import com.lcl.scs.lpv.lafreightservice.model.LaFreightFilter;

public interface LaFreightFilterService {

	void saveOrUpdateLAInboundFreightInformationFilter(LaFreightFilter laFreightFilter);

	List<LaFreightFilter> findByProcessIndicator(String indicator);
}
