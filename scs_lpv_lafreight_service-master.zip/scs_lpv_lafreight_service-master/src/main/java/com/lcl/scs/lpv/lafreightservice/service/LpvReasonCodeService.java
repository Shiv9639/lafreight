package com.lcl.scs.lpv.lafreightservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lcl.scs.lpv.lafreightservice.model.LAReasonCodeTransaction;
import com.lcl.scs.lpv.lafreightservice.model.LaFreightFilter;
import com.lcl.scs.lpv.lafreightservice.model.LpvReasonCode;


@Service
public interface LpvReasonCodeService {
	void saveLpvReasonCode(LpvReasonCode lpvReasonCode);

	void saveLpvReasonCodeTransaction(LAReasonCodeTransaction lpvReasonCodeTransaction);

	LAReasonCodeTransaction publishLpvReasonCodeTransaction(List<LpvReasonCode> lpvReasonCodeList, String shipmentNo, String messageId );
}
