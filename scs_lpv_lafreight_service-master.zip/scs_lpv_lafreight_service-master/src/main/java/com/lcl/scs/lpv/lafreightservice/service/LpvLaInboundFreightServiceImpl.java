package com.lcl.scs.lpv.lafreightservice.service;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import com.lcl.scs.lpv.lafreightservice.model.LAReasonCodeTransaction;
import com.lcl.scs.lpv.lafreightservice.model.LaFreightFilter;
import com.lcl.scs.lpv.lafreightservice.model.LpvLaDetailInterface;
import com.lcl.scs.lpv.lafreightservice.model.LpvToken;
import com.lcl.scs.subscribers.model.Subscribers;
import com.lcl.scs.lpv.lafreightservice.model.LpvReasonCode;
import com.lcl.scs.util.logging.LoggingUtilities;
import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;

public class LpvLaInboundFreightServiceImpl implements LpvLaInboundFreightService {
	private static final SimpleDateFormat DATEFORMAT = new SimpleDateFormat("EEE yyyy-MM-dd HH:mm:ss z");
	private static final SimpleDateFormat DATETIMEFORMATTER = new SimpleDateFormat("yyyyMMddHHmmss");
	private int LAST_RUN_TIME_BUFFER = 0;
	private String mongodbDatabase;
	private String BY_TOKEN_URL;
	private String BY_TOKEN_CLIENT_ID;
	private String BY_TOKEN_CLIENT_SECRET;
	private String BY_TOKEN_GRANT_TYPE;
	private String BY_TOKEN_SCOPE;
	private String mongodbURI;
	private LpvLaInboundFreightService lpvLaInboundService;
	private LaFreightFilterService laFreightFilterService;
	private LpvReasonCodeService lpvReasonCodeService;
	private com.lcl.scs.subscribers.service.SubscribersService subscribersService;
	private static final String EXPORT_PATH = System.getenv("FOLDER_NAME");
	private static final String BY_LPV_LA_API_URL = System.getenv("BY_LPV_LA_API_URL");
	private static final String BY_LPV_LA_DELIVERY_API_URL = System.getenv("BY_LPV_LA_DELIVERY_API_URL");
	private static final int MAX_LCT_CONNECTION = 100;

	List<LpvReasonCode> reasonCodeList = new ArrayList<LpvReasonCode>();
	HashMap<String, LpvReasonCode> reasonCodeMap = new HashMap<String, LpvReasonCode>();

	public LpvLaInboundFreightService getLpvLaInboundService() {
		return lpvLaInboundService;
	}

	public void setLpvLaInboundService(LpvLaInboundFreightService lpvLaInboundService) {
		this.lpvLaInboundService = lpvLaInboundService;
	}

	public LaFreightFilterService getLaFreightFilterService() {
		return laFreightFilterService;
	}

	public LpvReasonCodeService getLpvReasonCodeService() {
		return lpvReasonCodeService;
	}

	public void setLaFreightFilterService(LaFreightFilterService laFreightFilterService) {

		this.laFreightFilterService = laFreightFilterService;
	}

	public void setLpvReasonCodeService(LpvReasonCodeService lpvReasonCodeService) {
		this.lpvReasonCodeService = lpvReasonCodeService;
	}

	public void setSubscribersService(com.lcl.scs.subscribers.service.SubscribersService subscribersService) {
		this.subscribersService = subscribersService;
	}

	public void setBY_TOKEN_CLIENT_ID(String bY_TOKEN_CLIENT_ID) {
		BY_TOKEN_CLIENT_ID = bY_TOKEN_CLIENT_ID;
	}

	public void setBY_TOKEN_CLIENT_SECRET(String bY_TOKEN_CLIENT_SECRET) {
		BY_TOKEN_CLIENT_SECRET = bY_TOKEN_CLIENT_SECRET;
	}

	public void setBY_TOKEN_GRANT_TYPE(String bY_TOKEN_GRANT_TYPE) {
		BY_TOKEN_GRANT_TYPE = bY_TOKEN_GRANT_TYPE;
	}

	public void setBY_TOKEN_SCOPE(String bY_TOKEN_SCOPE) {
		BY_TOKEN_SCOPE = bY_TOKEN_SCOPE;
	}

	public void setBY_TOKEN_URL(String bY_TOKEN_URL) {
		BY_TOKEN_URL = bY_TOKEN_URL;
	}

	public void setMongodbDatabase(String mongodbDatabase) {
		this.mongodbDatabase = mongodbDatabase;
	}

	public void setMongodbURI(String mongodbURI) {
		this.mongodbURI = mongodbURI;
	}

	public void processLaInboundFreightInterface() throws Exception {
		MongoClient mongo = null;
		try {
			Date lastRunTime = new Date();
			mongo = MongoClients.create(mongodbURI);
			Subscribers subscriber = subscribersService.findByName("LPV-LA");

			LoggingUtilities.generateInfoLog("Last Run Time: " + DATEFORMAT.format(subscriber.getLastrun()));
			LoggingUtilities.generateInfoLog("Inbound Collection: " + subscriber.getInboundcollection());
			MongoCollection<Document> inbound_collection = mongo.getDatabase(mongodbDatabase)
					.getCollection(subscriber.getInboundcollection());
			MongoCollection<Document> outbound_collection = mongo.getDatabase(mongodbDatabase)
					.getCollection(subscriber.getOutboundcollection());
			MongoCollection<Document> reasonCodeCollection = mongo.getDatabase(mongodbDatabase)
					.getCollection("LpvReasonCodeCollection");
			FindIterable<Document> reasonCodes = reasonCodeCollection.find();

			for (Document code : reasonCodes) {
				LpvReasonCode lpvReasonCode = new LpvReasonCode();
				lpvReasonCode.setReasonCode((String) code.get("reasonCode"));
				lpvReasonCode.setReasonCodeDescription((String) code.get("reasonCodeDescription"));
				lpvReasonCode.setUserId("System");
				lpvReasonCode.setModifyDate(new Date());
				reasonCodeMap.put((String) code.get("reasonCode"), lpvReasonCode);
			}

			BasicDBObject query = new BasicDBObject();

			Calendar c = Calendar.getInstance();
			c.setTime(subscriber.getLastrun());
			c.add(Calendar.SECOND, LAST_RUN_TIME_BUFFER);
			Date previousRunTime = c.getTime();
			query.put("Loading_Time", new BasicDBObject("$gte", previousRunTime));
			Query q = new Query();
			q.fields().include("Loading_Time");
			MongoTemplate mongoTemplate = new MongoTemplate(mongo, mongodbDatabase);
			FindIterable<Document> documents = inbound_collection.find(query).sort(new BasicDBObject("_id", 1));
			Date processDate = new Date();
			LpvTokenServiceImpl tokenService = new LpvTokenServiceImpl();
			tokenService.setBY_TOKEN_URL(BY_TOKEN_URL);
			tokenService.setBY_TOKEN_CLIENT_ID(BY_TOKEN_CLIENT_ID);
			tokenService.setBY_TOKEN_CLIENT_SECRET(BY_TOKEN_CLIENT_SECRET);
			tokenService.setBY_TOKEN_GRANT_TYPE(BY_TOKEN_GRANT_TYPE);
			tokenService.setBY_TOKEN_SCOPE(BY_TOKEN_SCOPE);
			LpvToken lpvToken = tokenService.getLpvToken();
			for (Document doc : documents) {
				LaFreightFilter laFreightFilter = new LaFreightFilter();
//				LoggingUtilities.generateInfoLog("Service Starts");
				try {
					laFreightFilter = filterLAFreightData(doc);
					if (laFreightFilter == null)
						break;
					laFreightFilter.setLoadingDate(processDate);
					laFreightFilterService.saveOrUpdateLAInboundFreightInformationFilter(laFreightFilter);
				} catch (Exception ex) {
					LoggingUtilities.generateErrorLog(ex.getMessage());
				}

			}
			List<LaFreightFilter> laIdocsToBeExtract = laFreightFilterService.findByProcessIndicator("N");
			if (laIdocsToBeExtract.size() > 0) {

				String fileDate = DATETIMEFORMATTER.format(new Date());
				ExecutorService taskExecutor = Executors
						.newFixedThreadPool(laIdocsToBeExtract.size() > MAX_LCT_CONNECTION ? MAX_LCT_CONNECTION
								: laIdocsToBeExtract.size());
				int i = 0;
				for (LaFreightFilter laIdocFromDB : laIdocsToBeExtract) {
					taskExecutor.execute(new Runnable() {
						@Override
						public void run() {

							try {
								String laFileName = "lcl_lct_la_shipment_" + laIdocFromDB.getShipmentNo() + "_"
										+ laIdocFromDB.getMessageId() + "_" + fileDate + ".csv";
								String laDeliveryFileName = "lcl_lct_la_delivery_" + laIdocFromDB.getShipmentNo() + "_"
										+ laIdocFromDB.getMessageId() + "_" + fileDate + ".csv";
								laIdocFromDB.setLaFileName(laFileName);
								laIdocFromDB.setLaDeliveryFileName(laDeliveryFileName);
								generateLPVDeliveryLACSVFile(laIdocFromDB, lpvToken);
								generateLPVLACSVFile(laIdocFromDB, lpvToken);
								laIdocFromDB.setProcessIndicator("Y");
								laIdocFromDB.setProcessedTime(new Date());
								laFreightFilterService.saveOrUpdateLAInboundFreightInformationFilter(laIdocFromDB);
							} catch (Exception ex) {
								LoggingUtilities.generateErrorLog(ex.getMessage());
							}
						}
					});
				}
				taskExecutor.shutdown();
				taskExecutor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
			}

			mongo.close();
			subscriber.setLastrun(lastRunTime);
			subscribersService.saveOrUpdateSubscribers(subscriber);
		} catch (Exception ex) {
			LoggingUtilities.generateErrorLog(ex.getMessage());
			throw ex;
		} finally {
			if (mongo != null)
				mongo.close();
		}
	}
	@Override
	public List<LpvReasonCode> findReasonCode(String reasonCode) {
		List<LpvReasonCode> reasonCodelist = new ArrayList<LpvReasonCode>();
		reasonCodelist.add(reasonCodeMap.get(reasonCode));
		return reasonCodelist;
	}

	protected void generateLPVLACSVFile(LaFreightFilter laIdocFromDB, LpvToken lpvToken) throws Exception {
		FileWriter out = null;
		try {
			SimpleDateFormat lpvdateformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
			out = new FileWriter(EXPORT_PATH + "/" + laIdocFromDB.getLaFileName());

			CSVPrinter printer = new CSVPrinter(out,
					CSVFormat.DEFAULT.withHeader("Shipment No", "Order Type", "Process Type", "Shipment Type",
							"Ship Mode", "Country of Origin", "Planned Ship Date", "From Loc", "To Loc", "Line No",
							"From", "To", "Ship From Owner", "Ship To Owner", "Quantity", "Line Carrier ID",
							"Trailer No", "ETD", "Creation Date", "Creation-Date", "Container ETA", "Leg Ship From",
							"Leg Ship To", "Leg Ship From Owner", "Leg Ship To Owner", "Leg Carrier", "Leg Trailer No",
							"Leg ETA", "Leg Tracking Reference", "Leg Sequence", "Leg Ship Mode", "Operation Name",
							"Main Leg", "No of Deliveries", "Carrier", "Line Mode", "UDF Total Weight (LB)",
							"UDF Total Volume (CU FT)", "Packed Qty", "Equipment Type", "Service ID", "Carrier ID",
							"UDF Volume (CU FT)", "UDF Weight (LB)", "Vendor Name", "Full Replace", "Full Replace Line",
							"Ship State", "Plan Id", "Container ATA", "Transaction Id","UDF Reason Date","UDF Reason","UDF Reason Notes"));
			for (LpvLaDetailInterface lpvLaDetailInterface : laIdocFromDB.getLaDetails()) {

				printer.printRecord(laIdocFromDB.getShipmentNo(), laIdocFromDB.getOrderType(),
						laIdocFromDB.getProcessType(), laIdocFromDB.getShipmentType(), laIdocFromDB.getShipMode(),
						laIdocFromDB.getCountryOfOrigin(), laIdocFromDB.getPlannedShipDate(), laIdocFromDB.getFromLoc(),
						laIdocFromDB.getToLoc(), lpvLaDetailInterface.getLineNo(), lpvLaDetailInterface.getFrom(),
						lpvLaDetailInterface.getTo(), lpvLaDetailInterface.getShipFromOwner(),
						lpvLaDetailInterface.getShipToOwner(), "", lpvLaDetailInterface.getLineCarrierID(), "",
						lpvLaDetailInterface.getEtd(), laIdocFromDB.getCreationDate(), laIdocFromDB.getCreationDate(),
						lpvLaDetailInterface.getContainerEta(), lpvLaDetailInterface.getLegShipFrom(),
						lpvLaDetailInterface.getLegShipTo(), lpvLaDetailInterface.getLegShipFromOwner(),
						lpvLaDetailInterface.getLegShipToOwner(), "","", lpvLaDetailInterface.getLegEta(), "",
						lpvLaDetailInterface.getLegSequence(), laIdocFromDB.getLegShipMode(),
						laIdocFromDB.getOperationName(), laIdocFromDB.getMainLeg(), laIdocFromDB.getNoOfDeliveries(),
						lpvLaDetailInterface.getCarrier(), laIdocFromDB.getLineMode(), "", "", "", "", "RLTL",
						laIdocFromDB.getCarrierID(), "", "", "", laIdocFromDB.getFullReplace(),
						laIdocFromDB.getFullReplaceLine(), laIdocFromDB.getShipState(),
						lpvLaDetailInterface.getPlanId(), lpvLaDetailInterface.getContainerATA(),
						laIdocFromDB.getMessageId(),laIdocFromDB.getReasonDate(),laIdocFromDB.getReason(),laIdocFromDB.getReasonNotes());
			}
			out.flush();
			out.close();
			out = null;
			File file = new File(EXPORT_PATH + "/" + laIdocFromDB.getLaFileName());
			LpvLaAPIServiceImpl apiCall = new LpvLaAPIServiceImpl();
			LoggingUtilities.generateInfoLog("Processing " + laIdocFromDB.getLaFileName());
			apiCall.setLpvReasonCodeService(getLpvReasonCodeService());
			apiCall.setLpvLaInboundFreightService(getLpvLaInboundService());
			apiCall.postCSVFile(file, lpvToken, BY_LPV_LA_API_URL, "inboundShipmentLaMessage",laIdocFromDB);
			if (!file.delete()) {
				throw new Exception("Failed to delete file " + laIdocFromDB.getLaFileName());
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			if (out != null)
				out.close();
		}
	}

	protected void generateLPVDeliveryLACSVFile(LaFreightFilter laIdocFromDB, LpvToken lpvToken) throws Exception {
		FileWriter out = null;
		try {
			SimpleDateFormat lpvdateformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
			out = new FileWriter(EXPORT_PATH + "/" + laIdocFromDB.getLaDeliveryFileName());
			List<LpvLaDetailInterface> lpvLaDetailInterfaceList = laIdocFromDB.getLaDetails();
			LpvLaDetailInterface lpvLaDetailInterface = lpvLaDetailInterfaceList
					.get(lpvLaDetailInterfaceList.size() - 1);
			CSVPrinter printer = new CSVPrinter(out,
					CSVFormat.DEFAULT.withHeader("Delivery No", "Delivery Type", "Shipment Type", "Customer",
							"Supplier", "Shipment Line No", "Shipment No", "Trailer No", "Tractor No",
							"Transaction Id"));
			printer.printRecord(laIdocFromDB.getShipmentNo(), "inboundDelivery", "inboundShipment", "Loblaw",
					laIdocFromDB.getFromLoc(), lpvLaDetailInterface.getLineNo(), laIdocFromDB.getShipmentNo(),
					"Not Assigned", "Not Assigned", laIdocFromDB.getMessageId());
			out.flush();
			out.close();
			out = null;
			File file = new File(EXPORT_PATH + "/" + laIdocFromDB.getLaDeliveryFileName());
			LpvLaAPIServiceImpl apiCall = new LpvLaAPIServiceImpl();
			LoggingUtilities.generateInfoLog("Processing " + laIdocFromDB.getLaDeliveryFileName());
			apiCall.setLpvReasonCodeService(getLpvReasonCodeService());
			apiCall.setLpvLaInboundFreightService(getLpvLaInboundService());
			apiCall.postCSVFile(file, lpvToken, BY_LPV_LA_DELIVERY_API_URL, "deliveryShipmentLaMessage",laIdocFromDB);
			if (!file.delete()) {
				throw new Exception("Failed to delete file " + laIdocFromDB.getLaDeliveryFileName());
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			if (out != null)
				out.close();
		}
	}
//checking for mandatory fields 
	private boolean checkMandatoryFields(LaFreightFilter laFreightFilter) {
		boolean check = true;
		try {
		if (laFreightFilter.getShipmentNo().equals(null)
				|| laFreightFilter.getPlannedShipDate().equals(null)
				|| laFreightFilter.getFromLoc().equals(null) || laFreightFilter.getToLoc().equals(null)
				|| laFreightFilter.getCreationDate().equals(null)) {
			check = false;
		}
		List<LpvLaDetailInterface> laDetails = laFreightFilter.getLaDetails();
		
		for(LpvLaDetailInterface laDetail: laDetails) {
			if (laDetail.getLineNo().equals(null) || laDetail.getLegSequence().equals(null)
					|| laDetail.getFrom().equals(null) || laDetail.getTo().equals(null)
					|| laDetail.getCarrier().equals(null) || laDetail.getEtd().equals(null)
					|| laDetail.getLegShipFrom().equals(null) || laDetail.getLegShipTo().equals(null)
					|| laDetail.getContainerEta().equals(null)) {
			check = false;
			break;
			}
		}
		if (check == false) {
			List<LpvReasonCode> lpvReasonCodeList = findReasonCode("14");
			LAReasonCodeTransaction lpvReasonCodeTransaction = lpvReasonCodeService.publishLpvReasonCodeTransaction(
					lpvReasonCodeList, laFreightFilter.getShipmentNo(), laFreightFilter.getMessageId());
			lpvReasonCodeService.saveLpvReasonCodeTransaction(lpvReasonCodeTransaction);
		}}catch(Exception e) {
			List<LpvReasonCode> lpvReasonCodeList = findReasonCode("14");
			LAReasonCodeTransaction lpvReasonCodeTransaction = lpvReasonCodeService.publishLpvReasonCodeTransaction(
					lpvReasonCodeList, laFreightFilter.getShipmentNo(), laFreightFilter.getMessageId());
			lpvReasonCodeService.saveLpvReasonCodeTransaction(lpvReasonCodeTransaction);
			throw e;
		}
		return check;
	}

	private LaFreightFilter filterLAFreightData(Document doc) throws Exception {
		LaFreightFilter laFreightFilter = new LaFreightFilter();
		laFreightFilter.setOrderType("standardPO");
		laFreightFilter.setProcessType("supply");
		laFreightFilter.setShipmentType("inboundShipment");
		laFreightFilter.setShipMode("Road");
		laFreightFilter.setCountryOfOrigin("CAN");
		laFreightFilter.setLegShipMode("Road");
		laFreightFilter.setOperationName("CreateShipment");
		laFreightFilter.setMainLeg("TRUE");
		laFreightFilter.setNoOfDeliveries("1");
		laFreightFilter.setLineMode("Road");
		laFreightFilter.setFullReplace("line");
		laFreightFilter.setFullReplaceLine("leg");
		laFreightFilter.setShipState("N");
		laFreightFilter.setProcessIndicator("N");

		try {
			Document controlSection = (Document) doc.get("controlSection");
			laFreightFilter.setMessageId(controlSection.getString("messageId"));
			Document shipmentHeader = (Document) doc.get("shipmentHeader");
			laFreightFilter.setShipmentNo(shipmentHeader.getString("shipmentId"));
			laFreightFilter.setFromLoc(shipmentHeader.getString("fromLoc"));
			laFreightFilter.setToLoc(shipmentHeader.getString("toLoc"));
			laFreightFilter.setPlannedShipDate(shipmentHeader.getString("plannedShipDate"));
			laFreightFilter.setEta(shipmentHeader.getString("ETA"));
			laFreightFilter.setCreationDate(shipmentHeader.getString("creationDate"));
			Document ReasonNotes = (Document) doc.get("ReasonNotes");
			List<Document> reasonNotesList = new ArrayList();
			List<Document> reasonNotesObjects = new ArrayList();
			try {
				reasonNotesList.add((Document) doc.get("ReasonNotes"));
				for (String key : reasonNotesList.get(0).keySet()) {
					reasonNotesObjects.add((Document) ReasonNotes.get(key + ""));
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
				LoggingUtilities.generateErrorLog(ex.getMessage());
			}
			Document test=reasonNotesObjects.get(reasonNotesObjects.size()-1);
			laFreightFilter.setReason(test.getString("Reason"));
			laFreightFilter.setReasonDate(test.getString("ReasonCreateTime"));
			laFreightFilter.setReasonNotes(test.getString("ReasonNote"));
			Document shipmentLinesDoc = (Document) doc.get("shipmentLines");
			List<Document> lines = new ArrayList();
			List<Document> shipmentLines = new ArrayList();
			try {
				lines.add((Document) doc.get("shipmentLines"));
				for (String key : lines.get(0).keySet()) {
					// System.out.println(key);
					shipmentLines.add((Document) shipmentLinesDoc.get(key + ""));

				}

			} catch (Exception ex) {
				ex.printStackTrace();
				LoggingUtilities.generateErrorLog(ex.getMessage());
			}

			List<LpvLaDetailInterface> poDetails = new ArrayList<LpvLaDetailInterface>();
			if (shipmentLines != null) {
				for (Document shipmentLine : shipmentLines) {
					LpvLaDetailInterface poDetail = new LpvLaDetailInterface();
					poDetail.setLineNo(shipmentLine.getString("shipmentLineId").toString());
					poDetail.setCarrier(shipmentLine.getString("carrierName"));
					poDetail.setPlanId(shipmentLine.getString("LoadPlanId"));
					poDetail.setLineCarrierID(shipmentLine.getString("lineCarrierId"));
					poDetail.setFrom(shipmentLine.getString("shipFromSiteName"));
					poDetail.setTo(shipmentLine.getString("shipToSiteName"));
					poDetail.setShipFromOwner(shipmentLine.getString("shipFromSiteName"));
					poDetail.setShipToOwner(shipmentLine.getString("shipToSiteName"));
					poDetail.setContainerEta(shipmentLine.getString("containerETA"));
					poDetail.setEta(shipmentLine.getString("ETA"));
					poDetail.setEtd(shipmentLine.getString("ETD"));
					poDetail.setContainerATA(shipmentLine.getString("containerATA"));
					if (poDetail.getTo().startsWith("D")) {
						poDetail.setShipToOwner("Loblaw");
					} else {
						poDetail.setShipToOwner(poDetail.getTo());
					}
					if (poDetail.getFrom().startsWith("D")) {
						poDetail.setShipFromOwner("Loblaw");
					} else {
						poDetail.setShipFromOwner(poDetail.getFrom());
					}
					List<Document> shipmentLegs = new ArrayList();
					List<Document> legs = new ArrayList();
					shipmentLegs.add((Document) shipmentLine.get("shipmentLegs"));
					for (String key : shipmentLegs.get(0).keySet()) {
						// System.out.println(key);
						legs.add((Document) shipmentLegs.get(0).get(key + ""));

					}
					if (shipmentLegs != null) {
						for (Document shipmentLeg : legs) {

							if (shipmentLeg.getString("legshipFromSiteName") != null
									&& shipmentLeg.getString("legshipToSiteName") != null) {

								poDetail.setLegShipFrom(shipmentLeg.getString("legshipFromSiteName"));
								poDetail.setLegShipTo(shipmentLeg.getString("legshipToSiteName"));

								poDetail.setLegSequence(shipmentLeg.getString("legSequence"));
								poDetail.setLegEta(shipmentLeg.getString("legETA"));

								if (shipmentLeg.getString("legshipFromSiteName").startsWith("D")) {
									poDetail.setLegShipFromOwner("Loblaw");
								} else {
									poDetail.setLegShipFromOwner(shipmentLeg.getString("legshipFromSiteName"));
								}
								if (shipmentLeg.getString("legshipToSiteName").startsWith("D")) {
									poDetail.setLegShipToOwner("Loblaw");
								} else {
									poDetail.setLegShipToOwner(shipmentLeg.getString("legshipToSiteName"));
								}
							}
						}
					}
					poDetails.add(poDetail);
				}
				laFreightFilter.setLaDetails(poDetails);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		if(checkMandatoryFields(laFreightFilter)==true&&checkFieldsWithDummbyId(laFreightFilter)==true)
			return laFreightFilter;
		else
			return null;
	}

	private boolean checkFieldsWithDummbyId(LaFreightFilter laFreightFilter) {
		boolean check = true;
		try {
		
		if (laFreightFilter.getFromLoc().equals("9999999999") || laFreightFilter.getToLoc().equals("9999999999")) {
			check = false;
		}
		List<LpvLaDetailInterface> laDetails = laFreightFilter.getLaDetails();
		for(LpvLaDetailInterface laDetail: laDetails) {
			if (laDetail.getLegShipFrom().equals("9999999999") || laDetail.getLegShipTo().equals("9999999999")
					||laDetail.getTo().equals("9999999999")||laDetail.getFrom().equals("9999999999")) {
			check = false;
			break;
			}
		}
		
		if (check == false) {
			List<LpvReasonCode> lpvReasonCodeList = findReasonCode("23");
			LAReasonCodeTransaction lpvReasonCodeTransaction = lpvReasonCodeService.publishLpvReasonCodeTransaction(
					lpvReasonCodeList, laFreightFilter.getShipmentNo(), laFreightFilter.getMessageId());
			lpvReasonCodeService.saveLpvReasonCodeTransaction(lpvReasonCodeTransaction);
		}}catch(Exception e) {
			List<LpvReasonCode> lpvReasonCodeList = findReasonCode("14");
			LAReasonCodeTransaction lpvReasonCodeTransaction = lpvReasonCodeService.publishLpvReasonCodeTransaction(
					lpvReasonCodeList, laFreightFilter.getShipmentNo(), laFreightFilter.getMessageId());
			lpvReasonCodeService.saveLpvReasonCodeTransaction(lpvReasonCodeTransaction);
			throw e;
		}
		return check;
		
	}

}
