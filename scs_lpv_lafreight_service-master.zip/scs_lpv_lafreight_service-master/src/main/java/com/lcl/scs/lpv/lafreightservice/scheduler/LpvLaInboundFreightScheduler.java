package com.lcl.scs.lpv.lafreightservice.scheduler;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.lcl.scs.lpv.lafreightservice.service.LaFreightFilterService;
//import com.lcl.scs.lpv.lafreightservice.service.LpvLaInboundFreightService;
//import com.lcl.scs.lpv.lafreightservice.service.LpvLaInboundFreightService;
import com.lcl.scs.lpv.lafreightservice.service.LpvLaInboundFreightServiceImpl;
import com.lcl.scs.util.logging.LoggingUtilities;

@Component
public class LpvLaInboundFreightScheduler {
	private static final SimpleDateFormat DATETIMEFORMATTER = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");	
	private String mongodbURI = System.getenv("MONGO_DB_URI");	
	private String mongodbDatabase = System.getenv("MONGO_DB_NAME");	
		private final String BY_TOKEN_URL = System.getenv("BY_TOKEN_URL");
		private final String BY_TOKEN_CLIENT_ID = System.getenv("BY_TOKEN_CLIENT_ID");		
		private final String BY_TOKEN_CLIENT_SECRET = System.getenv("BY_TOKEN_CLIENT_SECRET");		
		private final String BY_TOKEN_GRANT_TYPE = System.getenv("BY_TOKEN_GRANT_TYPE");		
		private final String BY_TOKEN_SCOPE = System.getenv("BY_TOKEN_SCOPE");
		@Autowired
		private  LaFreightFilterService  laFreightFilterService;
		@Autowired
		private com.lcl.scs.subscribers.service.SubscribersService subscribersService;
		@Autowired
		private com.lcl.scs.lpv.lafreightservice.service.LpvReasonCodeService reasonCodeService;
		
		@Scheduled(fixedDelay = 1000 * 60 * 1)
		private void processLPVR9333Scheduler() {
			LoggingUtilities.generateInfoLog(DATETIMEFORMATTER.format(new Date()) + ": Start loading all new files");
			try {
				LoggingUtilities.generateInfoLog("MongoDB URI: " + mongodbURI);
				LoggingUtilities.generateInfoLog("MongoDB Database Name: " + mongodbDatabase);
				LpvLaInboundFreightServiceImpl lpvLaInboundFreightServiceImpl = new LpvLaInboundFreightServiceImpl();

				
				lpvLaInboundFreightServiceImpl.setBY_TOKEN_URL(BY_TOKEN_URL);
				lpvLaInboundFreightServiceImpl.setBY_TOKEN_CLIENT_ID(BY_TOKEN_CLIENT_ID);
				lpvLaInboundFreightServiceImpl.setBY_TOKEN_CLIENT_SECRET(BY_TOKEN_CLIENT_SECRET);
				lpvLaInboundFreightServiceImpl.setBY_TOKEN_GRANT_TYPE(BY_TOKEN_GRANT_TYPE);
				lpvLaInboundFreightServiceImpl.setBY_TOKEN_SCOPE(BY_TOKEN_SCOPE);
				lpvLaInboundFreightServiceImpl.setMongodbDatabase(mongodbDatabase);
				lpvLaInboundFreightServiceImpl.setMongodbURI(mongodbURI);
				
				lpvLaInboundFreightServiceImpl.setSubscribersService(subscribersService);
				lpvLaInboundFreightServiceImpl.setLaFreightFilterService(laFreightFilterService);
				lpvLaInboundFreightServiceImpl.setLpvReasonCodeService(reasonCodeService);
				lpvLaInboundFreightServiceImpl.setLpvLaInboundService(lpvLaInboundFreightServiceImpl);
				lpvLaInboundFreightServiceImpl.processLaInboundFreightInterface();
			} catch (Exception ex) {
				LoggingUtilities.generateErrorLog("Failed to load all new files! " + ex.getMessage());
				ex.printStackTrace();
			}
			LoggingUtilities
					.generateInfoLog(DATETIMEFORMATTER.format(new Date()) + ": Finish loading all new LA files for LPV");

		}
}
