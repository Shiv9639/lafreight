package com.lcl.scs.lpv.lafreightservice.service;

import java.util.List;

import com.lcl.scs.lpv.lafreightservice.model.LpvReasonCode;

public interface LpvLaInboundFreightService {
	List<LpvReasonCode> findReasonCode(String reasonCode);
}
