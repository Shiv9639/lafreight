package com.lcl.scs.lpv.lafreightservice.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.EntityBuilder;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.lcl.scs.lpv.lafreightservice.model.LAReasonCodeTransaction;
import com.lcl.scs.lpv.lafreightservice.model.LaFreightFilter;
import com.lcl.scs.lpv.lafreightservice.model.LpvReasonCode;

import com.lcl.scs.lpv.lafreightservice.model.LpvToken;
import com.lcl.scs.util.logging.LoggingUtilities;

public class LpvLaAPIServiceImpl  {
	private final String CONTENT_TYPE = "application/csv";
	private String fileName;
	private String authorization;
	private final String SENDER = "LOBLAWS.INC";
	private final String RECEIVERS = "LCT.GLOBAL";
	private final String BULK_FORMAT = "CSV";
	private final String ENTITY_VERSION = "BY-2020.1.0";
	private final String MODEL = "native";
	private final String RESPONSE_UTC_TIME_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	private final String OUTPUT_TIME_FORMATTER = "yyyy-MM-dd HH:mm:ss.SSS z";
	private LpvReasonCodeService lpvReasonCodeService;
	private LpvLaInboundFreightService lpvLaInboundFreightService;

	private List<BasicNameValuePair> getLpvParams(String entityName) {
		List<BasicNameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("sender", SENDER));
		params.add(new BasicNameValuePair("receivers", RECEIVERS));
		params.add(new BasicNameValuePair("entity", entityName));
		params.add(new BasicNameValuePair("bulkFormat", BULK_FORMAT));
		params.add(new BasicNameValuePair("entityVersion", ENTITY_VERSION));
		params.add(new BasicNameValuePair("model", MODEL));
		// new parameter requested from BY to send CSV file name
		params.add(new BasicNameValuePair("bulkId",getFileName().replace(".csv", "")));
//		LoggingUtilities.generateInfoLog("bulkId :" + getFileName().replace(".csv", ""));
		return params;
	}

	public void postCSVFile(File csvFile, LpvToken token, String url, String entityName,LaFreightFilter laFreightFilter ) throws Exception {
		try {
			setFileName(csvFile.getName());
			HttpClient client = HttpClientBuilder.create().build();
			HttpPost post = new HttpPost(url.concat("&bulkId="+getFileName().replace(".csv", "")));
			post.setHeader(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE);
			post.setHeader(HttpHeaders.AUTHORIZATION, token.getToken_type() + " " + token.getAccess_token());
			post.setEntity(new UrlEncodedFormEntity(getLpvParams(entityName)));
			// ContentType.create("application/csv") was changed to
			// "application/octet-stream" on BY request
			post.setEntity(EntityBuilder.create().setBinary(Files.readAllBytes(csvFile.toPath()))
					.setContentType(org.apache.http.entity.ContentType.create("application/csv")).build());
//			LoggingUtilities.generateInfoLog("post " + getLpvParams(entityName));
			HttpResponse response = client.execute(post);
			processLpvResponse(response, url,laFreightFilter);
		} catch (Exception ex) {
			throw ex;
		}
	}

	private void processLpvResponse(HttpResponse response, String url,LaFreightFilter laFreightFilter) throws IOException, Exception {
		LoggingUtilities.generateInfoLog("Got response from lpv.");
		if (response == null) {
			LoggingUtilities.generateErrorLog("Empty LCT API Response: ");
			throw new Exception("Invalid Response from " + url);
		}
		int code = response.getStatusLine().getStatusCode();
		HttpEntity responseEntity = response.getEntity();
		String responseStr = EntityUtils.toString(responseEntity);
		if (code == 202) {
			JSONObject responseJSON = new JSONObject(responseStr);

			LpvInterfaceResponse resp = new LpvInterfaceResponse();
			resp.setIngestionId(responseJSON.getString("ingestionId"));

			try {
				resp.setStatus(responseJSON.getString("status"));

				if (responseJSON.get("timeStamp") != null) {
					try {
						LocalDateTime utc_time = LocalDateTime.parse(responseJSON.get("timeStamp").toString(),
								DateTimeFormatter.ofPattern(RESPONSE_UTC_TIME_FORMATTER));
						ZoneId utc = ZoneId.of("UTC");
						ZoneId est = ZoneId.of("Canada/Eastern");
						ZonedDateTime utcZonedDateTime = utc_time.atZone(utc);
						ZonedDateTime estDateTime = utcZonedDateTime.withZoneSameInstant(est);
						resp.setTimeStamp(estDateTime);
					} catch (Exception ex) {
						LocalDateTime et = LocalDateTime.now();
						ZoneId est = ZoneId.of("Canada/Eastern");
						ZonedDateTime etTime = et.atZone(est);
						ZonedDateTime estDateTime = etTime.withZoneSameInstant(est);
						resp.setTimeStamp(estDateTime);
					}
				}

				resp.setMessage(responseJSON.getString("message"));

				LoggingUtilities.generateInfoLog("LCT API Message: "
						+ resp.getTimeStamp().format(DateTimeFormatter.ofPattern(OUTPUT_TIME_FORMATTER)) + ": "
						+ resp.getMessage());
			} catch (Exception ex) {
				LoggingUtilities.generateErrorLog("Response Code: " + code);
				LoggingUtilities.generateInfoLog("LCT API Response: " + responseStr);
				if(url.contains("inboundShipment")) {
				List<LpvReasonCode> lpvReasonCodeList = getLpvLaInboundFreightService().findReasonCode("13");
				LAReasonCodeTransaction lpvReasonCodeTransaction = getLpvReasonCodeService()
						.publishLpvReasonCodeTransaction(lpvReasonCodeList, laFreightFilter.getShipmentNo(),laFreightFilter.getMessageId());
				getLpvReasonCodeService().saveLpvReasonCodeTransaction(lpvReasonCodeTransaction);
				}
			}
		} else {
			LoggingUtilities.generateErrorLog("Received failure from lpv");
			LoggingUtilities.generateErrorLog("Response Code: " + code);
			LoggingUtilities.generateInfoLog("LCT API Response: " + responseStr);
			if(url.contains("inboundShipment")) {
			List<LpvReasonCode> lpvReasonCodeList = getLpvLaInboundFreightService().findReasonCode("97");
			LAReasonCodeTransaction lpvReasonCodeTransaction = getLpvReasonCodeService()
					.publishLpvReasonCodeTransaction(lpvReasonCodeList, laFreightFilter.getShipmentNo(),laFreightFilter.getMessageId());
			getLpvReasonCodeService().saveLpvReasonCodeTransaction(lpvReasonCodeTransaction);
			}	
			throw new Exception("Invalid Response from " + url);
		}
	}

	public String getAuthorization() {
		return authorization;
	}

	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public LpvReasonCodeService getLpvReasonCodeService() {
		return lpvReasonCodeService;
	}

	public void setLpvReasonCodeService(LpvReasonCodeService lpvReasonCodeService) {
		this.lpvReasonCodeService = lpvReasonCodeService;
	}

	public LpvLaInboundFreightService getLpvLaInboundFreightService() {
		return lpvLaInboundFreightService;
	}

	public void setLpvLaInboundFreightService(LpvLaInboundFreightService lpvLaInboundFreightService) {
		this.lpvLaInboundFreightService = lpvLaInboundFreightService;
	}
	
}
