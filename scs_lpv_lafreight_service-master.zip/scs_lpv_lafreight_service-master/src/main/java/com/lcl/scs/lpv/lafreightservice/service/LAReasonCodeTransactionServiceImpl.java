package com.lcl.scs.lpv.lafreightservice.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lcl.scs.lpv.lafreightservice.repository.LAReasonCodeTransactionRepository;
import com.lcl.scs.lpv.lafreightservice.model.LAReasonCodeTransaction;
import com.lcl.scs.lpv.lafreightservice.model.LaFreightFilter;
import com.lcl.scs.lpv.lafreightservice.model.LpvReasonCode;
import com.lcl.scs.lpv.lafreightservice.repository.LpvReasonCodeRepository;


@Service
public class LAReasonCodeTransactionServiceImpl implements LpvReasonCodeService{
	@Autowired
	private LpvReasonCodeRepository lpvReasonCodeRepository;

	@Autowired
	private LAReasonCodeTransactionRepository laReasonCodeTransactionRepository;

	@Override
	public void saveLpvReasonCode(LpvReasonCode lpvReasonCode) {
		// TODO Auto-generated method stub
		lpvReasonCodeRepository.save(lpvReasonCode);
	}

	@Override
	public void saveLpvReasonCodeTransaction(LAReasonCodeTransaction lpvReasonCodeTransaction) {
		// TODO Auto-generated method stub
		laReasonCodeTransactionRepository.save(lpvReasonCodeTransaction);
	}

	@Override
	public LAReasonCodeTransaction publishLpvReasonCodeTransaction(List<LpvReasonCode> lpvReasonCodeList, String shipmentNo, String messageId) {
		// TODO Auto-generated method stub
		LAReasonCodeTransaction lpvReasonCodeTransaction = new LAReasonCodeTransaction();
		if (lpvReasonCodeList != null && !lpvReasonCodeList.isEmpty()) {
			for (LpvReasonCode lpvReasonCode : lpvReasonCodeList) {
				lpvReasonCodeTransaction.setReasonCode(lpvReasonCode.getReasonCode());
				lpvReasonCodeTransaction.setShipmentNo(shipmentNo);
				lpvReasonCodeTransaction.setMessageId(messageId);
				lpvReasonCodeTransaction.setTime(new Date());
				lpvReasonCodeTransaction.setReasonCodeDescription(lpvReasonCode.getReasonCodeDescription());
				return lpvReasonCodeTransaction;
			}
		}
		return lpvReasonCodeTransaction;
	}


}
