package com.lcl.scs.lpv.lafreightservice.model;

public class LpvLaDetailInterface {
	private String lineNo;
	private String carrier;
	private String lineCarrierID;
	private String legShipFrom;
	private String legShipTo;
	private String legShipFromOwner;
	private String legSequence;
	private String legShipToOwner;
	private String legEta;
	private String planId;
	private String from;
	private String to;
	private String shipToOwner;
	private String shipFromOwner;
	private String containerEta;
	private String eta;
	private String etd; 
	private String containerATA;
	
	public String getShipToOwner() {
		return shipToOwner;
	}
	public void setShipToOwner(String shipToOwner) {
		this.shipToOwner = shipToOwner;
	}
	public String getShipFromOwner() {
		return shipFromOwner;
	}
	public void setShipFromOwner(String shipFromOwner) {
		this.shipFromOwner = shipFromOwner;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getLegSequence() {
		return legSequence;
	}
	public void setLegSequence(String legSequence) {
		this.legSequence = legSequence;
	}
	public String getLineCarrierID() {
		return lineCarrierID;
	}
	public void setLineCarrierID(String lineCarrierID) {
		this.lineCarrierID = lineCarrierID;
	}
	public String getLineNo() {
		return lineNo;
	}
	public void setLineNo(String lineNo) {
		this.lineNo = lineNo;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public String getLegShipFrom() {
		return legShipFrom;
	}
	public void setLegShipFrom(String legShipFrom) {
		this.legShipFrom = legShipFrom;
	}
	public String getLegShipTo() {
		return legShipTo;
	}
	public void setLegShipTo(String legShipTo) {
		this.legShipTo = legShipTo;
	}
	public String getLegShipFromOwner() {
		return legShipFromOwner;
	}
	public void setLegShipFromOwner(String legShipFromOwner) {
		this.legShipFromOwner = legShipFromOwner;
	}
	public String getLegShipToOwner() {
		return legShipToOwner;
	}
	public void setLegShipToOwner(String legShipToOwner) {
		this.legShipToOwner = legShipToOwner;
	}
	public String getContainerEta() {
		return containerEta;
	}
	public void setContainerEta(String containerEta) {
		this.containerEta = containerEta;
	}
	public String getEta() {
		return eta;
	}
	public void setEta(String eta) {
		this.eta = eta;
	}
	public String getEtd() {
		return etd;
	}
	public void setEtd(String etd) {
		this.etd = etd;
	}
	public String getLegEta() {
		return legEta;
	}
	public void setLegEta(String legEta) {
		this.legEta = legEta;
	}
	public String getContainerATA() {
		return containerATA;
	}
	public void setContainerATA(String containerATA) {
		this.containerATA = containerATA;
	}
	
}
