package com.lcl.scs.lpv.lafreightservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.lcl.scs.lpv.lafreightservice.model.LAReasonCodeTransaction;

@Repository
public interface LAReasonCodeTransactionRepository extends MongoRepository<LAReasonCodeTransaction, String>{

}
