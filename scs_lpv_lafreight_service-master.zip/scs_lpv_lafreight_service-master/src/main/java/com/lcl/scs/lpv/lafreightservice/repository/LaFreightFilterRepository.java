package com.lcl.scs.lpv.lafreightservice.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.lcl.scs.lpv.lafreightservice.model.LaFreightFilter;

@Repository
public interface LaFreightFilterRepository extends MongoRepository<LaFreightFilter, String>{

	List<LaFreightFilter> findByProcessIndicator(String indicator);

}
