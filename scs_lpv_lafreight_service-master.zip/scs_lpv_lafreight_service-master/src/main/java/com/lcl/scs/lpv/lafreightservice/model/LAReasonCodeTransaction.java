package com.lcl.scs.lpv.lafreightservice.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="LAReasonCodeTransaction")
public class LAReasonCodeTransaction {
	private String reasonCode;
	private String shipmentNo; 
	private String messageId;
	private Date time;
	private String reasonCodeDescription;
	
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getReasonCodeDescription() {
		return reasonCodeDescription;
	}
	public void setReasonCodeDescription(String reasonCodeDescription) {
		this.reasonCodeDescription = reasonCodeDescription;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}

	
}
