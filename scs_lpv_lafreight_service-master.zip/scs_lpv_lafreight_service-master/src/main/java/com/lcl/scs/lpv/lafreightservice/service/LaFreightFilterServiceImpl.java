package com.lcl.scs.lpv.lafreightservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lcl.scs.lpv.lafreightservice.model.LaFreightFilter;
import com.lcl.scs.lpv.lafreightservice.repository.LaFreightFilterRepository;

@Service
public class LaFreightFilterServiceImpl implements LaFreightFilterService{
	
	@Autowired
	private LaFreightFilterRepository laFreightFilterRepository;
	@Override
	public void saveOrUpdateLAInboundFreightInformationFilter(LaFreightFilter laFreightFilter) {
		laFreightFilterRepository.save(laFreightFilter);
	}
	@Override
	public List<LaFreightFilter> findByProcessIndicator(String indicator) {
		// TODO Auto-generated method stub
		return laFreightFilterRepository.findByProcessIndicator(indicator);
	}
	
}
