package com.lcl.scs.scslpvlafreightservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScsLpvLafreightServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
