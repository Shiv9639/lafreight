# SCS_LPV_LAFreight_Service

Purpose: To take new documents received in LAInboundFreightInformation collection from LA and filter the relevant ones into the LAInboundFreightInformationFilter collection in MongoDB (relevant to LCT project only). 